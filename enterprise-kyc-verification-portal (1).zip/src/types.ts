/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface CustomerData {
  name: string;
  dob: string;
  address: string;
  panNumber: string;
  aadhaarNumber: string;
  mobileNumber: string;
  email: string;
}

export interface DocumentConsistency {
  nameMatchScore: number; // 0 to 100
  dobMatchScore: number;  // 0 to 100
  addressMatchScore: number; // 0 to 100
  panFormatOk: boolean;
  aadhaarFormatOk: boolean;
  observations: string;
}

export interface MissingFieldCheck {
  missingSignatures: boolean;
  blankFields: string[];
  missingIds: string[];
  lowQualityImages: boolean;
  observations: string;
}

export interface FraudRiskDetection {
  fakePanDetected: boolean;
  fakeAadhaarDetected: boolean;
  suspiciousMismatch: boolean;
  duplicateIdentity: boolean;
  editedDocuments: boolean;
  riskLevel: 'LOW' | 'MEDIUM' | 'HIGH';
  riskScore: number; // 0 to 100
  reasons: string[];
}

export interface FinalKycReport {
  verificationSummary: string;
  missingFieldsSummary: string;
  fraudAnalysisSummary: string;
  finalRecommendation: string;
  finalStatus: 'VERIFIED' | 'PARTIALLY VERIFIED' | 'REJECTED' | 'MANUAL REVIEW REQUIRED';
}

export interface AuditLog {
  timestamp: string;
  message: string;
  actor: string;
}

export interface KycApplication {
  id: string;
  customerName: string;
  customerEmail: string;
  submittedAt: string;
  updatedAt: string;
  
  // Document base64 contents
  aadhaarImageName: string | null;
  aadhaarImage: string | null; // Data URI if uploaded
  panImageName: string | null;
  panImage: string | null;
  formImageName: string | null;
  formImage: string | null;

  // AI Pipeline details
  currentStep: 'UPLOADED' | 'EXTRACTED' | 'CHECKED_CONSISTENCY' | 'CHECKED_MISSING' | 'DETECTED_FRAUD' | 'COMPLETED' | 'FAILED';
  stepProgress: number; // e.g. 0 to 100

  // Outputs of individual steps
  customerData: CustomerData | null;
  consistencyCheck: DocumentConsistency | null;
  missingFieldsCheck: MissingFieldCheck | null;
  fraudDetection: FraudRiskDetection | null;
  finalKycReport: FinalKycReport | null;

  // Final manual action details
  status: 'VERIFIED' | 'PARTIALLY VERIFIED' | 'REJECTED' | 'MANUAL REVIEW REQUIRED' | 'PROCESSING' | 'PENDING_UPLOAD';
  adminNotes: string | null;
  requestedDocuments: string[] | null; // Docs admin requested to re-upload
  auditLogs: AuditLog[];
}
