/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from "react";
import {
  Shield,
  FileCheck,
  User,
  CheckCircle2,
  AlertTriangle,
  XCircle,
  Clock,
  ArrowRight,
  Upload,
  FileText,
  Download,
  Check,
  RefreshCw,
  Search,
  Database,
  Building,
  Info,
  ChevronRight,
  Menu,
  X,
  FileCode,
  Sliders,
  Sparkles
} from "lucide-react";
import { KycApplication, CustomerData } from "./types";

export default function App() {
  // Navigation & View states
  const [currentPortal, setCurrentPortal] = useState<"customer" | "authority">("customer");
  const [activeTab, setActiveTab] = useState<"dashboard" | "pending" | "high-risk" | "audit">("dashboard");
  const [applications, setApplications] = useState<KycApplication[]>([]);
  const [selectedAppId, setSelectedAppId] = useState<string | null>(null);
  
  // Customer Session States
  const [customerEmail, setCustomerEmail] = useState("");
  const [customerName, setCustomerName] = useState("");
  const [activeCustomerApp, setActiveCustomerApp] = useState<KycApplication | null>(null);
  const [isCustomerLoggedIn, setIsCustomerLoggedIn] = useState(false);
  const [customerLoginError, setCustomerLoginError] = useState("");

  // Customer Status Quick Check State Values
  const [customerLandingTab, setCustomerLandingTab] = useState<"register" | "lookup">("register");
  const [statusCheckQuery, setStatusCheckQuery] = useState("");
  const [statusCheckResult, setStatusCheckResult] = useState<KycApplication | null>(null);
  const [statusCheckError, setStatusCheckError] = useState("");

  const isAadhaarFlagged = activeCustomerApp?.requestedDocuments?.some(doc => 
    doc.toLowerCase().includes("aadhaar") || doc.toLowerCase().includes("national")
  ) || false;
  const isPanFlagged = activeCustomerApp?.requestedDocuments?.some(doc => 
    doc.toLowerCase().includes("pan") || doc.toLowerCase().includes("tax")
  ) || false;
  const isFormFlagged = activeCustomerApp?.requestedDocuments?.some(doc => 
    doc.toLowerCase().includes("form") || doc.toLowerCase().includes("sign") || doc.toLowerCase().includes("enrollment")
  ) || false;

  // Upload fields
  const [aadhaarFile, setAadhaarFile] = useState<string | null>(null);
  const [aadhaarName, setAadhaarName] = useState<string | null>(null);
  const [panFile, setPanFile] = useState<string | null>(null);
  const [panName, setPanName] = useState<string | null>(null);
  const [formFile, setFormFile] = useState<string | null>(null);
  const [formName, setFormName] = useState<string | null>(null);

  // Status message states
  const [uploadMessage, setUploadMessage] = useState("");
  const [processingAi, setProcessingAi] = useState(false);
  const [feedbackMessage, setFeedbackMessage] = useState<{ type: "success" | "error"; text: string } | null>(null);

  // Filter/Search states for Authority Portal
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState<string>("ALL");
  const [riskFilter, setRiskFilter] = useState<string>("ALL");
  const [auditorName, setAuditorName] = useState("V. Pulikonda (Lead Auditor)");

  // Admin Actions Panel States
  const [adminNotes, setAdminNotes] = useState("");
  const [docRequestList, setDocRequestList] = useState<string[]>([]);
  const [customDocRequest, setCustomDocRequest] = useState("");

  // Refs for uploads
  const aadhaarInputRef = useRef<HTMLInputElement>(null);
  const panInputRef = useRef<HTMLInputElement>(null);
  const formInputRef = useRef<HTMLInputElement>(null);

  // Load applications initial fetch
  useEffect(() => {
    fetchApplications();
    const interval = setInterval(fetchApplications, 4000); // Poll server updates
    return () => clearInterval(interval);
  }, []);

  const fetchApplications = async () => {
    try {
      const res = await fetch("/api/kyc/applications");
      if (res.ok) {
        const data = await res.json();
        setApplications(data);
      }
    } catch (err) {
      console.error("Error fetching applications", err);
    }
  };

  // Synchronize active logged in customer's details when applications array changes
  useEffect(() => {
    if (activeCustomerApp) {
      const fresh = applications.find(a => a.id === activeCustomerApp.id);
      if (fresh) {
        if (JSON.stringify(fresh) !== JSON.stringify(activeCustomerApp)) {
          setActiveCustomerApp(fresh);
        }
      }
    }
  }, [applications, activeCustomerApp]);

  // Preset upload triggers to expedite visual evaluation
  const applyPresetIdentity = (type: "clear" | "mismatch" | "fraud" | "incomplete") => {
    // Fill realistic images and names instantly
    if (type === "clear") {
      setCustomerName("Aditya Vardhan Sharma");
      setCustomerEmail("aditya.sharma@enterprise.in");
      setAadhaarName("aadhaar_aditya_verif.png");
      setPanName("pan_aditya_verif.png");
      setFormName("kyc_form_aditya_verif.png");
      const samplePixel = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNk+M9QDwADhgGAWjR9awAAAABJRU5ErkJggg==";
      setAadhaarFile(samplePixel);
      setPanFile(samplePixel);
      setFormFile(samplePixel);
    } else if (type === "mismatch") {
      setCustomerName("Priya Nair");
      setCustomerEmail("priya.nair@nairassociates.co");
      setAadhaarName("aadhaar_priya_mismatch.png");
      setPanName("pan_priya_mismatch.png");
      setFormName("form_priya_mismatch.png");
      const samplePixel = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNk+M9QDwADhgGAWjR9awAAAABJRU5ErkJggg==";
      setAadhaarFile(samplePixel);
      setPanFile(samplePixel);
      setFormFile(samplePixel);
    } else if (type === "fraud") {
      setCustomerName("Rajesh Kumar Verma");
      setCustomerEmail("rajesh.verma72@gmail.com");
      setAadhaarName("aadhaar_fabricated_stamp.png");
      setPanName("pan_verma_genuine.png");
      setFormName("form_verma_genuine.png");
      const samplePixel = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNk+M9QDwADhgGAWjR9awAAAABJRU5ErkJggg==";
      setAadhaarFile(samplePixel);
      setPanFile(samplePixel);
      setFormFile(samplePixel);
    } else {
      setCustomerName("Ananya Deshmukh");
      setCustomerEmail("ananya.deshmukh@gmail.com");
      setAadhaarName("aadhaar_ananya_res.png");
      setPanName("pan_ananya_res.png");
      setFormName("form_unsigned_blank.png");
      const samplePixel = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNk+M9QDwADhgGAWjR9awAAAABJRU5ErkJggg==";
      setAadhaarFile(samplePixel);
      setPanFile(samplePixel);
      setFormFile(samplePixel);
    }
    setUploadMessage("Preset identities applied. Ready for registration and authentication.");
  };

  const handleCustomerRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    setCustomerLoginError("");
    if (!customerName || !customerEmail) {
      setCustomerLoginError("Please enter physical full name and business email address.");
      return;
    }

    try {
      const res = await fetch("/api/kyc/applications", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ customerName, customerEmail })
      });

      if (res.ok) {
        const data = await res.json();
        setActiveCustomerApp(data);
        setIsCustomerLoggedIn(true);
        // Prepopulate based on whether documents were uploaded
        if (data.aadhaarImageName) setAadhaarName(data.aadhaarImageName);
        if (data.panImageName) setPanName(data.panImageName);
        if (data.formImageName) setFormName(data.formImageName);
      } else {
        const errData = await res.json();
        setCustomerLoginError(errData.error || "Failed registering profile");
      }
    } catch (err) {
      setCustomerLoginError("Unable to establish remote secure endpoint link.");
    }
  };

  const handleStatusLookup = (e: React.FormEvent) => {
    e.preventDefault();
    setStatusCheckError("");
    setStatusCheckResult(null);

    const query = statusCheckQuery.trim().toLowerCase();
    if (!query) {
      setStatusCheckError("Please enter your registered secure email or unique Application Reference ID.");
      return;
    }

    const found = applications.find(
      a => a.id.toLowerCase() === query || a.customerEmail.toLowerCase() === query
    );

    if (found) {
      setStatusCheckResult(found);
    } else {
      setStatusCheckError("No onboarding record discovered with that Email address or unique Reference ID.");
    }
  };

  const handleAutoLoginAndUpload = (app: KycApplication) => {
    setCustomerName(app.customerName);
    setCustomerEmail(app.customerEmail);
    setActiveCustomerApp(app);
    setIsCustomerLoggedIn(true);
    if (app.aadhaarImageName) setAadhaarName(app.aadhaarImageName);
    if (app.panImageName) setPanName(app.panImageName);
    if (app.formImageName) setFormName(app.formImageName);
  };

  const fileToDataUri = (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = (e) => {
        resolve(e.target?.result as string);
      };
      reader.onerror = reject;
      reader.readAsDataURL(file);
    });
  };

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>, type: "aadhaar" | "pan" | "form") => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      try {
        const dataUri = await fileToDataUri(file);
        if (type === "aadhaar") {
          setAadhaarFile(dataUri);
          setAadhaarName(file.name);
        } else if (type === "pan") {
          setPanFile(dataUri);
          setPanName(file.name);
        } else {
          setFormFile(dataUri);
          setFormName(file.name);
        }
        setUploadMessage(`Loaded document: ${file.name}`);
      } catch (err) {
        setUploadMessage("Security block: Corrupted image stream file.");
      }
    }
  };

  const executeSubmitFiles = async () => {
    if (!activeCustomerApp) return;

    if (!aadhaarFile && !panFile && !formFile) {
      setUploadMessage("Upload error: At least one identity card file is required.");
      return;
    }

    setUploadMessage("Transmitting cryptographically secure image stream payload...");
    try {
      const res = await fetch(`/api/kyc/applications/${activeCustomerApp.id}/upload`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          aadhaarFile,
          aadhaarName,
          panFile,
          panName,
          formFile,
          formName
        })
      });

      if (res.ok) {
        const updated = await res.json();
        setActiveCustomerApp(updated);
        setUploadMessage("Encryption tunnel successful. System processing is ready.");
        // Fetch fresh compliance registers
        fetchApplications();
        // Trigger AI automation pipeline
        triggerAiBackend(updated.id);
      } else {
        setUploadMessage("Compliance failure during secure transfer handshakes.");
      }
    } catch (err) {
      setUploadMessage("Connection terminated by proxy layer during upload.");
    }
  };

  const triggerAiBackend = async (id: string) => {
    setProcessingAi(true);
    try {
      const res = await fetch(`/api/kyc/applications/${id}/process-ai`, {
        method: "POST"
      });
      if (res.ok) {
        const complete = await res.json();
        setActiveCustomerApp(complete);
        // Sync application grid state
        fetchApplications();
      }
    } catch (err) {
      console.error("AI Service Error", err);
    } finally {
      setProcessingAi(false);
    }
  };

  // Authority Admin Actions
  const handleAdminAction = async (status: "VERIFIED" | "REJECTED" | "MANUAL REVIEW REQUIRED" | "PARTIALLY VERIFIED") => {
    if (!selectedAppId) return;

    try {
      const res = await fetch(`/api/kyc/applications/${selectedAppId}/action`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          status,
          adminNotes,
          auditorName
        })
      });

      if (res.ok) {
        const updated = await res.json();
        setApplications(prev => prev.map(a => a.id === selectedAppId ? updated : a));
        setAdminNotes("");
        setFeedbackMessage({ type: "success", text: `Application ${selectedAppId} marked successfully as ${status}.` });
        setTimeout(() => setFeedbackMessage(null), 4000);
      }
    } catch (err) {
      setFeedbackMessage({ type: "error", text: "Compliance registry action write failed." });
    }
  };

  const handleRequestMoreDocs = async () => {
    if (!selectedAppId || docRequestList.length === 0) return;

    try {
      const res = await fetch(`/api/kyc/applications/${selectedAppId}/request-docs`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          requestedDocuments: docRequestList,
          adminNotes: adminNotes || "Additional proof requested.",
          auditorName
        })
      });

      if (res.ok) {
        const updated = await res.json();
        setApplications(prev => prev.map(a => a.id === selectedAppId ? updated : a));
        setDocRequestList([]);
        setAdminNotes("");
        setFeedbackMessage({ type: "success", text: `Additional files request submitted to customer profile.` });
        setTimeout(() => setFeedbackMessage(null), 4000);
      }
    } catch (err) {
      setFeedbackMessage({ type: "error", text: "Database query action error on file request." });
    }
  };

  const toggleDocRequestItem = (doc: string) => {
    if (docRequestList.includes(doc)) {
      setDocRequestList(prev => prev.filter(item => item !== doc));
    } else {
      setDocRequestList(prev => [...prev, doc]);
    }
  };

  const addCustomDocRequest = () => {
    if (customDocRequest.trim()) {
      setDocRequestList(prev => [...prev, customDocRequest.trim()]);
      setCustomDocRequest("");
    }
  };

  // Download Compliance Report File
  const handleDownloadReport = (appId: string) => {
    window.open(`/api/kyc/applications/${appId}/report`, "_blank");
  };

  // Filter application sets
  const filteredApps = applications.filter(app => {
    const textMatch = 
      app.customerName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      app.customerEmail.toLowerCase().includes(searchTerm.toLowerCase()) ||
      app.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (app.customerData?.panNumber && app.customerData.panNumber.toLowerCase().includes(searchTerm.toLowerCase())) ||
      (app.customerData?.aadhaarNumber && app.customerData.aadhaarNumber.toLowerCase().includes(searchTerm.toLowerCase()));

    const statusMatch = statusFilter === "ALL" || app.status === statusFilter;
    const riskMatch = riskFilter === "ALL" || app.fraudDetection?.riskLevel === riskFilter;

    return textMatch && statusMatch && riskMatch;
  });

  const selectedApp = applications.find(a => a.id === selectedAppId);

  // Status Badge renderer
  const renderStatusBadge = (status: string) => {
    switch (status) {
      case "VERIFIED":
        return (
          <span className="inline-flex items-center gap-1.5 px-3 py-1 bg-emerald-50 text-emerald-700 border border-emerald-200 rounded-full text-xs font-bold">
            <CheckCircle2 size={13} className="text-emerald-600" />
            VERIFIED
          </span>
        );
      case "REJECTED":
        return (
          <span className="inline-flex items-center gap-1.5 px-3 py-1 bg-rose-50 text-rose-700 border border-rose-200 rounded-full text-xs font-bold">
            <XCircle size={13} className="text-rose-600" />
            REJECTED
          </span>
        );
      case "PARTIALLY VERIFIED":
        return (
          <span className="inline-flex items-center gap-1.5 px-3 py-1 bg-amber-50 text-amber-700 border border-amber-200 rounded-full text-xs font-bold">
            <AlertTriangle size={13} className="text-amber-600" />
            PARTIAL LIMIT
          </span>
        );
      case "MANUAL REVIEW REQUIRED":
        return (
          <span className="inline-flex items-center gap-1.5 px-3 py-1 bg-blue-50 text-blue-700 border border-blue-200 rounded-full text-xs font-bold">
            <Clock size={13} className="text-blue-600" />
            MANUAL AUDIT
          </span>
        );
      case "PROCESSING":
        return (
          <span className="inline-flex items-center gap-1.5 px-3 py-1 bg-slate-100 text-slate-700 border border-slate-200 rounded-full text-xs font-bold animate-pulse">
            <RefreshCw size={13} className="animate-spin text-slate-500" />
            AI RUNNING
          </span>
        );
      default:
        return (
          <span className="inline-flex items-center gap-1.5 px-3 py-1 bg-slate-50 text-slate-600 border border-slate-200 rounded-full text-xs font-bold">
            <Clock size={13} />
            DRAFT PENDING
          </span>
        );
    }
  };

  // Risk level badge
  const renderRiskBadge = (level: "LOW" | "MEDIUM" | "HIGH" | undefined) => {
    if (!level) return <span className="text-slate-400 font-medium">None</span>;
    switch (level) {
      case "LOW":
        return <span className="px-2.5 py-1 bg-emerald-50 text-emerald-700 border border-emerald-200 rounded text-[10px] font-bold">LOW RISK</span>;
      case "MEDIUM":
        return <span className="px-2.5 py-1 bg-amber-50 text-amber-700 border border-amber-200 rounded text-[10px] font-bold">MEDIUM WARNING</span>;
      case "HIGH":
        return <span className="px-2.5 py-1 bg-rose-50 text-rose-700 border border-rose-200 rounded text-[10px] font-bold animate-bounce">HIGH CRITICAL</span>;
    }
  };

  // Reset local state variables
  const logoutCustomer = () => {
    setActiveCustomerApp(null);
    setIsCustomerLoggedIn(false);
    setCustomerEmail("");
    setCustomerName("");
    setAadhaarFile(null);
    setAadhaarName(null);
    setPanFile(null);
    setPanName(null);
    setFormFile(null);
    setFormName(null);
    setUploadMessage("");
  };

  return (
    <div className="min-h-screen bg-[#F8FAFC] text-[#0F172A] font-sans flex flex-col antialiased">
      {/* ENTERPRISE TITLE HEADER & NAVIGATION */}
      <nav className="h-16 bg-[#0F172A] text-white flex items-center justify-between px-8 shrink-0 shadow-lg relative z-30">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 bg-sky-500 rounded flex items-center justify-center font-black text-white text-lg tracking-tight shadow">RV</div>
          <div className="leading-tight">
            <span className="text-lg font-bold tracking-tight block">RESERVE VAULT</span>
            <span className="text-[10px] text-sky-400 tracking-wider uppercase font-semibold">ENTERPRISE KYC AUDITOR v3.5</span>
          </div>
        </div>
        
        <div className="flex gap-6 items-center">
          {/* Main Portal Switcher */}
          <div className="flex bg-slate-900 rounded-lg p-1 border border-slate-800 text-xs font-semibold shadow-inner">
            <button
              onClick={() => {
                setCurrentPortal("customer");
                // Select first application or none for admin view focus separation
              }}
              className={`px-4 py-1.5 rounded-md transition-all duration-300 ${
                currentPortal === "customer"
                  ? "bg-sky-500 text-white shadow-md"
                  : "text-slate-400 hover:text-white"
              }`}
            >
              CUSTOMER PORTAL
            </button>
            <button
              onClick={() => {
                setCurrentPortal("authority");
                if (applications.length > 0 && !selectedAppId) {
                  setSelectedAppId(applications[0].id);
                }
              }}
              className={`px-4 py-1.5 rounded-md transition-all duration-300 ${
                currentPortal === "authority"
                  ? "bg-sky-500 text-white shadow-md"
                  : "text-slate-400 hover:text-white"
              }`}
            >
              AUTHORITY SYSTEM
            </button>
          </div>

          <div className="hidden md:flex items-center gap-3 border-l border-slate-800 pl-6">
            <div className="text-right">
              {currentPortal === "authority" ? (
                <>
                  <p className="text-xs font-bold text-slate-100">{auditorName}</p>
                  <p className="text-[9px] text-sky-400 tracking-wider font-mono">ID: SEC-ARCH-2026</p>
                </>
              ) : (
                <>
                  <p className="text-xs font-bold text-slate-300">{isCustomerLoggedIn ? customerName : "Anonymous Session"}</p>
                  <p className="text-[9px] text-slate-500 tracking-wider font-mono">{isCustomerLoggedIn ? customerEmail : "Access Gateway"}</p>
                </>
              )}
            </div>
            <div className={`w-8 h-8 rounded-full flex items-center justify-center font-bold text-white text-xs ${currentPortal === 'authority' ? 'bg-sky-600' : 'bg-slate-700'}`}>
              {currentPortal === "authority" ? "AD" : (isCustomerLoggedIn ? customerName.slice(0, 2).toUpperCase() : "?")}
            </div>
          </div>
        </div>
      </nav>

      {/* COMPONENT CONTENT BODY LAYOUT */}
      <div className="flex-1 flex flex-col md:flex-row overflow-hidden">
        
        {/* ========================================== */}
        {/* CUSTOMER PORTAL VIEW                       */}
        {/* ========================================== */}
        {currentPortal === "customer" && (
          <div className="flex-1 overflow-y-auto px-4 py-6 md:p-8 max-w-6xl mx-auto w-full flex flex-col gap-8">
            <header className="border-b border-slate-200 pb-5">
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                <div>
                  <h1 className="text-3xl font-extrabold tracking-tight text-[#0F172A]">Safe Account Onboarding</h1>
                  <p className="text-slate-500 text-sm mt-1">
                    Provide legal identifiers (PAN/Aadhaar) and register with our cryptographically guided AI screening engine.
                  </p>
                </div>
                {isCustomerLoggedIn && (
                  <button 
                    onClick={logoutCustomer}
                    className="self-start text-xs font-semibold px-3 py-1.5 bg-white border border-slate-300 hover:bg-slate-50 rounded-lg text-slate-600 transition"
                  >
                    Exit Client Portal
                  </button>
                )}
              </div>
            </header>

            {!isCustomerLoggedIn ? (
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
                {/* Info and Presets Card */}
                <div className="lg:col-span-5 flex flex-col gap-6">
                  <div className="bg-slate-900 text-white rounded-2xl shadow-xl p-6 border border-slate-800 space-y-4">
                    <div className="flex items-center gap-2 text-sky-400">
                      <Sparkles size={18} />
                      <h4 className="text-xs uppercase tracking-wider font-bold">One-Click Demonstration Mockups</h4>
                    </div>
                    <p className="text-xs text-slate-300 leading-relaxed">
                      To help banking auditors verify both positive alignment results and critical AI alerts, select one of the pre-configured compliance personas below:
                    </p>
                    <div className="space-y-2.5 pt-2">
                      <button
                        onClick={() => applyPresetIdentity("clear")}
                        className="w-full text-left p-3 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-700/60 flex items-center justify-between text-xs transition"
                      >
                        <div>
                          <p className="font-bold text-emerald-400">1. Clean Record Profile</p>
                          <p className="text-slate-400 text-[10px]">Aditya Sharma — Fully Compliant Matches</p>
                        </div>
                        <span className="px-2 py-0.5 bg-emerald-950/80 border border-emerald-800 text-emerald-400 rounded-full text-[9px] font-semibold uppercase">Low Risk</span>
                      </button>

                      <button
                        onClick={() => applyPresetIdentity("mismatch")}
                        className="w-full text-left p-3 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-700/60 flex items-center justify-between text-xs transition"
                      >
                        <div>
                          <p className="font-bold text-amber-400">2. Mismatched Date Verification</p>
                          <p className="text-slate-400 text-[10px]">Priya Nair — DOB mismatch (Aadhaar 1991 vs Form 1992)</p>
                        </div>
                        <span className="px-2 py-0.5 bg-amber-950/80 border border-amber-800 text-amber-400 rounded-full text-[9px] font-semibold uppercase">Medium Risk</span>
                      </button>

                      <button
                        onClick={() => applyPresetIdentity("fraud")}
                        className="w-full text-left p-3 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-700/60 flex items-center justify-between text-xs transition"
                      >
                        <div>
                          <p className="font-bold text-rose-400">3. Artificial Tampering Warning</p>
                          <p className="text-slate-400 text-[10px]">Rajesh Verma — Fake Aadhaar Card signature layer</p>
                        </div>
                        <span className="px-2 py-0.5 bg-rose-950/80 border border-rose-800 text-rose-400 rounded-full text-[9px] font-semibold uppercase">High Fraud</span>
                      </button>

                      <button
                        onClick={() => applyPresetIdentity("incomplete")}
                        className="w-full text-left p-3 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-700/60 flex items-center justify-between text-xs transition"
                      >
                        <div>
                          <p className="font-bold text-blue-400">4. Unsigned Incomplete Document</p>
                          <p className="text-slate-400 text-[10px]">Ananya Deshmukh — Missing signature signature box</p>
                        </div>
                        <span className="px-2 py-0.5 bg-blue-950/80 border border-blue-800 text-blue-400 rounded-full text-[9px] font-semibold uppercase">Partial Limit</span>
                      </button>
                    </div>
                  </div>

                  <div className="bg-white rounded-2xl border border-slate-200 p-6 space-y-4">
                    <h3 className="text-sm font-bold text-slate-800 flex items-center gap-2">
                      <Shield size={16} className="text-sky-600" />
                      Compliance Audit Standards
                    </h3>
                    <ul className="space-y-2.5 text-xs text-slate-500">
                      <li className="flex items-start gap-2">
                        <Check size={14} className="text-emerald-500 mt-0.5 shrink-0" />
                        Names are evaluated using Jaro-Winkler string algorithms to check for typing similarity.
                      </li>
                      <li className="flex items-start gap-2">
                        <Check size={14} className="text-emerald-500 mt-0.5 shrink-0" />
                        Cryptographic check-digit mathematics validates legal Aadhaar string IDs.
                      </li>
                      <li className="flex items-start gap-2">
                        <Check size={14} className="text-emerald-500 mt-0.5 shrink-0" />
                        Risk flags automatically report forgery artifacts, overlays, and document level edits.
                      </li>
                    </ul>
                  </div>
                </div>

                {/* Login Registration Card */}
                <div className="lg:col-span-7 bg-white rounded-2xl border border-slate-200 shadow-sm p-6 md:p-8 flex flex-col gap-6">
                  {/* Tab Selector */}
                  <div className="flex border-b border-slate-100 pb-1">
                    <button
                      onClick={() => {
                        setCustomerLandingTab("register");
                        setCustomerLoginError("");
                      }}
                      className={`pb-3 text-sm font-bold tracking-tight border-b-2 px-1 transition duration-200 mr-6 ${
                        customerLandingTab === "register"
                          ? "border-sky-500 text-sky-600"
                          : "border-transparent text-slate-400 hover:text-slate-600"
                      }`}
                    >
                      Onshore Safe Register
                    </button>
                    <button
                      onClick={() => {
                        setCustomerLandingTab("lookup");
                        setStatusCheckResult(null);
                        setStatusCheckError("");
                      }}
                      className={`pb-3 text-sm font-bold tracking-tight border-b-2 px-1 transition duration-200 ${
                        customerLandingTab === "lookup"
                          ? "border-sky-500 text-sky-600"
                          : "border-transparent text-slate-400 hover:text-slate-600"
                      }`}
                    >
                      Check Status & Re-audits
                    </button>
                  </div>

                  {customerLandingTab === "register" ? (
                    <div className="space-y-4">
                      <h2 className="text-lg font-bold tracking-tight text-[#0F172A]">Safe Onboarding Portal</h2>
                      <form onSubmit={handleCustomerRegister} className="space-y-5">
                        {customerLoginError && (
                          <div className="p-3 bg-rose-50 border border-rose-100 rounded-lg text-rose-700 text-xs font-semibold">
                            {customerLoginError}
                          </div>
                        )}
                        
                        <div className="space-y-1.5">
                          <label className="text-xs font-bold text-slate-600 block uppercase tracking-wider">Customer Legal Full Name</label>
                          <input
                            type="text"
                            placeholder="e.g. Aditya Vardhan Sharma"
                            value={customerName}
                            onChange={(e) => setCustomerName(e.target.value)}
                            className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-sm focus:bg-white focus:outline-none focus:ring-2 focus:ring-sky-500/20 focus:border-sky-500 transition"
                          />
                        </div>

                        <div className="space-y-1.5">
                          <label className="text-xs font-bold text-slate-600 block uppercase tracking-wider">Business Security Email Address</label>
                          <input
                            type="email"
                            placeholder="e.g. aditya.sharma@enterprise.in"
                            value={customerEmail}
                            onChange={(e) => setCustomerEmail(e.target.value)}
                            className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-sm focus:bg-white focus:outline-none focus:ring-2 focus:ring-sky-500/20 focus:border-sky-500 transition"
                          />
                        </div>

                        {uploadMessage && (
                          <div className="p-3 text-xs bg-slate-50 border border-slate-200 rounded-lg text-slate-600 flex items-center gap-2">
                             <Info size={14} className="text-sky-500" />
                             {uploadMessage}
                          </div>
                        )}

                        <button
                          type="submit"
                          className="w-full bg-sky-600 hover:bg-sky-700 text-white py-3.5 px-6 rounded-xl font-bold text-sm tracking-wide shadow transition flex items-center justify-center gap-2"
                        >
                          Enter Secured Vault System
                          <ArrowRight size={16} />
                        </button>
                      </form>
                    </div>
                  ) : (
                    <div className="space-y-6">
                      <div>
                        <h2 className="text-lg font-bold tracking-tight text-[#0F172A]">Instant Status Search</h2>
                        <p className="text-xs text-slate-400 mt-1">Retrieve audit findings using your registration email address or ID reference link.</p>
                      </div>

                      <form onSubmit={handleStatusLookup} className="flex gap-2">
                        <div className="flex-1">
                          <input
                            type="text"
                            placeholder="Enter unique Customer Email or Ref Card ID..."
                            value={statusCheckQuery}
                            onChange={(e) => setStatusCheckQuery(e.target.value)}
                            className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-2.5 text-xs focus:bg-white focus:outline-none focus:ring-2 focus:ring-sky-500/20 focus:border-sky-500 transition"
                          />
                        </div>
                        <button
                          type="submit"
                          className="bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs uppercase tracking-wider px-5 py-2.5 rounded-xl transition shadow flex items-center gap-1 shrink-0"
                        >
                          <Search size={14} />
                          Query
                        </button>
                      </form>

                      {statusCheckError && (
                        <div className="p-3 bg-rose-50 border border-rose-100 rounded-lg text-rose-700 text-xs font-semibold">
                          {statusCheckError}
                        </div>
                      )}

                      {statusCheckResult ? (
                        <div className={`p-5 rounded-2xl border transition duration-300 space-y-4 ${
                          statusCheckResult.requestedDocuments && statusCheckResult.requestedDocuments.length > 0
                            ? "bg-[#FFFbeb] border-amber-300 shadow-sm"
                            : statusCheckResult.status === "VERIFIED"
                            ? "bg-emerald-50/70 border-emerald-200 shadow-sm"
                            : statusCheckResult.status === "REJECTED"
                            ? "bg-rose-50/70 border-rose-200 shadow-sm"
                            : "bg-slate-50 border-slate-200"
                        }`}>
                          <div className="flex justify-between items-start flex-wrap gap-2 border-b border-slate-200/50 pb-3">
                            <div>
                              <h4 className="text-xs font-extrabold text-slate-800 uppercase tracking-wider">{statusCheckResult.customerName}</h4>
                              <p className="text-[10px] text-slate-500 font-mono mt-0.5">{statusCheckResult.customerEmail}</p>
                            </div>
                            <div className="flex gap-1.5 items-center">
                              {renderStatusBadge(statusCheckResult.status)}
                            </div>
                          </div>

                          <div className="grid grid-cols-2 gap-4">
                            <div>
                              <p className="text-[9px] font-bold text-slate-400 tracking-wider uppercase">Reference ID</p>
                              <p className="text-xs font-semibold text-slate-800 font-mono mt-0.5">{statusCheckResult.id}</p>
                            </div>
                            <div>
                              <p className="text-[9px] font-bold text-slate-400 tracking-wider uppercase">Completion Rate</p>
                              <div className="flex items-center gap-1.5 mt-0.5">
                                <div className="w-full bg-slate-200 h-1.5 rounded-full overflow-hidden max-w-[60px]">
                                  <div className="bg-sky-500 h-full" style={{ width: `${statusCheckResult.stepProgress}%` }}></div>
                                </div>
                                <span className="text-[10px] font-bold text-slate-600">{statusCheckResult.stepProgress}%</span>
                              </div>
                            </div>
                          </div>

                          {/* RE-AUDIT ALERT */}
                          {statusCheckResult.requestedDocuments && statusCheckResult.requestedDocuments.length > 0 ? (
                            <div className="p-3 bg-amber-100/80 border border-amber-200 rounded-xl space-y-2">
                              <div className="flex items-center gap-1.5 text-amber-800">
                                <AlertTriangle size={15} className="text-amber-600 animate-bounce" />
                                <p className="text-[10px] font-black uppercase tracking-wider">Re-Auditing Requirements Demanded</p>
                              </div>
                              <p className="text-[10.5px] text-amber-800 font-medium">
                                The compliance authority reviewed your submission and flagged issue(s) with the following. Please re-upload immediately:
                              </p>
                              <ul className="list-disc pl-4 text-[10.5px] text-amber-800 space-y-1">
                                {statusCheckResult.requestedDocuments.map((doc, idx) => (
                                  <li key={idx} className="font-bold">{doc}</li>
                                ))}
                              </ul>
                              {statusCheckResult.adminNotes && (
                                <p className="text-[10.5px] text-amber-700 italic border-t border-amber-200/50 pt-1.5 mt-1">
                                  Auditor Context: &ldquo;{statusCheckResult.adminNotes}&rdquo;
                                </p>
                              )}
                            </div>
                          ) : (
                            <div className="text-xs text-slate-600 bg-white/70 p-3 rounded-xl border border-slate-100">
                              <p className="font-semibold text-slate-800">Review Summary Remarks:</p>
                              <p className="text-slate-500 text-[11px] mt-1 italic">
                                {statusCheckResult.finalKycReport?.verificationSummary || "No official auditor decision summaries registered yet. Security screen is in line."}
                              </p>
                            </div>
                          )}

                          <div className="pt-2 flex justify-end">
                            <button
                              onClick={() => handleAutoLoginAndUpload(statusCheckResult)}
                              className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-black rounded-lg transition shadow-md flex items-center justify-center gap-1.5 uppercase tracking-wide"
                            >
                              {statusCheckResult.requestedDocuments && statusCheckResult.requestedDocuments.length > 0 ? (
                                <>
                                  <RefreshCw size={12} className="animate-spin-slow" />
                                  Fix Issues & Re-upload Now
                                </>
                              ) : (
                                <>
                                  Enter Dashboard Session
                                  <ArrowRight size={12} />
                                </>
                              )}
                            </button>
                          </div>
                        </div>
                      ) : (
                        <div className="border border-dashed border-slate-200 rounded-2xl p-6 text-center text-slate-400">
                          <Database size={24} className="mx-auto mb-2 text-slate-300" />
                          <p className="text-xs">Provide matching lookup values above to extract compliance status findings instantly.</p>
                        </div>
                      )}
                    </div>
                  )}
                </div>
              </div>
            ) : (
              /* Active Onboard Portal */
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
                {/* Left Panel: Upload System and Local Status trackers */}
                <div className="lg:col-span-7 space-y-6">
                  <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm space-y-6">
                    <div className="flex justify-between items-center border-b border-slate-100 pb-4">
                      <div>
                        <h2 className="font-bold text-lg text-slate-800">Identify Document Check</h2>
                        <p className="text-slate-400 text-xs">Verify identity matching guidelines automatically</p>
                      </div>
                      <span className="text-[10.5px] font-mono bg-sky-50 text-sky-700 px-2 py-1 rounded border border-sky-100">
                        REF ID: {activeCustomerApp.id}
                      </span>
                    </div>

                    {activeCustomerApp.requestedDocuments && activeCustomerApp.requestedDocuments.length > 0 && (
                      <div className="p-4 bg-orange-50 border border-orange-200 rounded-xl space-y-2">
                        <div className="flex items-center gap-2 text-orange-800">
                          <AlertTriangle size={16} />
                          <p className="text-xs font-bold uppercase tracking-wider">Action Required: Document Re-Upload Requested</p>
                        </div>
                        <ul className="list-disc pl-5 text-xs text-orange-700">
                          {activeCustomerApp.requestedDocuments.map((doc, i) => (
                            <li key={i} className="font-medium">{doc}</li>
                          ))}
                        </ul>
                        {activeCustomerApp.adminNotes && (
                          <p className="text-[11px] text-orange-600 italic mt-1 border-t border-orange-100 pt-1">
                            Auditor Note: &ldquo;{activeCustomerApp.adminNotes}&rdquo;
                          </p>
                        )}
                      </div>
                    )}

                    <div className="space-y-4">
                      {/* File Card Aadhaar */}
                      <div className={`flex flex-col md:flex-row md:items-center justify-between p-4 rounded-xl border transition duration-200 gap-3 ${
                        isAadhaarFlagged 
                          ? "bg-rose-50/70 border-rose-300 shadow-sm" 
                          : "bg-slate-50 border-slate-200/80"
                      }`}>
                        <div className="flex items-center gap-3">
                          <div className={`w-10 h-10 rounded-lg flex items-center justify-center border transition ${
                            isAadhaarFlagged ? 'bg-white text-rose-500 border-rose-200' : 'bg-white text-slate-400 border-slate-200'
                          }`}>
                            <FileText size={18} />
                          </div>
                          <div>
                            <div className="flex items-center gap-2 flex-wrap">
                              <p className="text-xs font-extrabold text-slate-800 uppercase tracking-wide">1. National ID (Aadhaar Card)</p>
                              {isAadhaarFlagged && (
                                <span className="inline-flex items-center gap-1 px-2 py-0.5 bg-rose-100 text-rose-800 border border-rose-200 rounded text-[9px] font-black uppercase tracking-wider animate-pulse">
                                  <AlertTriangle size={10} className="text-rose-600" />
                                  Issue Flagged: Re-upload Needed
                                </span>
                              )}
                            </div>
                            <p className="text-slate-400 text-[10px]">{aadhaarName || "No file uploaded"}</p>
                          </div>
                        </div>
                        <div>
                          <input
                            type="file"
                            accept="image/*"
                            ref={aadhaarInputRef}
                            onChange={(e) => handleFileChange(e, "aadhaar")}
                            className="hidden"
                          />
                          <button
                            onClick={() => aadhaarInputRef.current?.click()}
                            className={`text-xs font-bold border px-3.5 py-2 rounded-lg transition ${
                              isAadhaarFlagged 
                                ? "bg-rose-600 border-rose-600 hover:bg-rose-700 text-white shadow-md font-extrabold" 
                                : "border-slate-200 bg-white hover:bg-slate-100 text-slate-700"
                            }`}
                          >
                            {isAadhaarFlagged ? "Re-upload Aadhaar" : (aadhaarName ? "Replace Image" : "Upload Aadhaar")}
                          </button>
                        </div>
                      </div>

                      {/* File Card PAN */}
                      <div className={`flex flex-col md:flex-row md:items-center justify-between p-4 rounded-xl border transition duration-200 gap-3 ${
                        isPanFlagged 
                          ? "bg-rose-50/70 border-rose-300 shadow-sm" 
                          : "bg-slate-50 border-slate-200/80"
                      }`}>
                        <div className="flex items-center gap-3">
                          <div className={`w-10 h-10 rounded-lg flex items-center justify-center border transition ${
                            isPanFlagged ? 'bg-white text-rose-500 border-rose-200' : 'bg-white text-slate-400 border-slate-200'
                          }`}>
                            <FileCheck size={18} />
                          </div>
                          <div>
                            <div className="flex items-center gap-2 flex-wrap">
                              <p className="text-xs font-extrabold text-slate-800 uppercase tracking-wide">2. Tax ID (PAN Card)</p>
                              {isPanFlagged && (
                                <span className="inline-flex items-center gap-1 px-2 py-0.5 bg-rose-100 text-rose-800 border border-rose-200 rounded text-[9px] font-black uppercase tracking-wider animate-pulse">
                                  <AlertTriangle size={10} className="text-rose-600" />
                                  Issue Flagged: Re-upload Needed
                                </span>
                              )}
                            </div>
                            <p className="text-slate-400 text-[10px]">{panName || "No file uploaded"}</p>
                          </div>
                        </div>
                        <div>
                          <input
                            type="file"
                            accept="image/*"
                            ref={panInputRef}
                            onChange={(e) => handleFileChange(e, "pan")}
                            className="hidden"
                          />
                          <button
                            onClick={() => panInputRef.current?.click()}
                            className={`text-xs font-bold border px-3.5 py-2 rounded-lg transition ${
                              isPanFlagged 
                                ? "bg-rose-600 border-rose-600 hover:bg-rose-700 text-white shadow-md font-extrabold" 
                                : "border-slate-200 bg-white hover:bg-slate-100 text-slate-700"
                            }`}
                          >
                            {isPanFlagged ? "Re-upload PAN Card" : (panName ? "Replace Image" : "Upload PAN Card")}
                          </button>
                        </div>
                      </div>

                      {/* File Card Customer Form */}
                      <div className={`flex flex-col md:flex-row md:items-center justify-between p-4 rounded-xl border transition duration-200 gap-3 ${
                        isFormFlagged 
                          ? "bg-rose-50/70 border-rose-300 shadow-sm" 
                          : "bg-slate-50 border-slate-200/80"
                      }`}>
                        <div className="flex items-center gap-3">
                          <div className={`w-10 h-10 rounded-lg flex items-center justify-center border transition ${
                            isFormFlagged ? 'bg-white text-rose-500 border-rose-200' : 'bg-white text-slate-400 border-slate-200'
                          }`}>
                            <Sliders size={18} />
                          </div>
                          <div>
                            <div className="flex items-center gap-2 flex-wrap">
                              <p className="text-xs font-extrabold text-slate-800 uppercase tracking-wide">3. Customer Account Request Form</p>
                              {isFormFlagged && (
                                <span className="inline-flex items-center gap-1 px-2 py-0.5 bg-rose-100 text-rose-800 border border-rose-200 rounded text-[9px] font-black uppercase tracking-wider animate-pulse">
                                  <AlertTriangle size={10} className="text-rose-600" />
                                  Issue Flagged: Re-upload Needed
                                </span>
                              )}
                            </div>
                            <p className="text-slate-400 text-[10px]">{formName || "No file uploaded"}</p>
                          </div>
                        </div>
                        <div>
                          <input
                            type="file"
                            accept="image/*"
                            ref={formInputRef}
                            onChange={(e) => handleFileChange(e, "form")}
                            className="hidden"
                          />
                          <button
                            onClick={() => formInputRef.current?.click()}
                            className={`text-xs font-bold border px-3.5 py-2 rounded-lg transition ${
                              isFormFlagged 
                                ? "bg-rose-600 border-rose-600 hover:bg-rose-700 text-white shadow-md font-extrabold" 
                                : "border-slate-200 bg-white hover:bg-slate-100 text-slate-700"
                            }`}
                          >
                            {isFormFlagged ? "Re-upload Form" : (formName ? "Replace Image" : "Upload Form")}
                          </button>
                        </div>
                      </div>
                    </div>

                    {uploadMessage && (
                      <div className="p-3 bg-slate-100 border border-slate-200 rounded-lg text-xs font-semibold text-slate-700 flex items-center gap-2">
                        <Database size={14} className="text-indigo-600 animate-pulse" />
                        <span>{uploadMessage}</span>
                      </div>
                    )}

                    <div className="pt-2 border-t border-slate-100 flex items-center justify-between gap-4">
                      <p className="text-[11px] text-slate-400 leading-tight">
                        Our platform securely transfers visual binary layers with ISO 27001 TLS specifications directly to compliance processors.
                      </p>
                      <button
                        onClick={executeSubmitFiles}
                        disabled={processingAi}
                        className={`px-6 py-3 bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs uppercase tracking-wider rounded-xl transition shadow shrink-0 ${processingAi ? 'opacity-50 cursor-not-allowed' : ''}`}
                      >
                        {processingAi ? "Processing AI..." : "Transmit & Analyze"}
                      </button>
                    </div>
                  </div>

                  {/* Customer Portal Audit Logs Timeline */}
                  {activeCustomerApp.auditLogs && (
                    <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm">
                      <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-4">Submission Transaction Logs</h3>
                      <div className="space-y-4">
                        {activeCustomerApp.auditLogs.map((log, i) => (
                          <div key={i} className="flex gap-3 text-xs items-start">
                            <span className="w-1.5 h-1.5 bg-indigo-500 rounded-full mt-1.5 shrink-0"></span>
                            <div className="space-y-0.5">
                              <p className="text-slate-800 font-semibold">{log.message}</p>
                              <p className="text-[10px] text-slate-400">
                                {new Date(log.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })} &middot; Action by {log.actor}
                              </p>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>

                {/* Right Panel: Active Status tracker widget */}
                <div className="lg:col-span-5 space-y-6">
                  {/* Real-time Status Badge Tracker Card */}
                  <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 text-white shadow-xl flex flex-col gap-5">
                    <div className="flex justify-between items-start gap-4">
                      <div>
                        <p className="text-[10px] text-sky-400 uppercase tracking-widest font-bold">Onboarding State</p>
                        <h2 className="text-xl font-extrabold tracking-tight mt-1">Status Summary</h2>
                      </div>
                      <div className="bg-slate-800 px-3 py-1.5 rounded-lg border border-slate-700 text-xs font-bold text-slate-300">
                        {activeCustomerApp.status}
                      </div>
                    </div>

                    {/* Progress tracker visually mapping standard AI steps */}
                    <div className="space-y-3.5 my-2">
                      <div className="flex justify-between text-xs text-slate-300 font-bold">
                        <span>Evaluation Progress</span>
                        <span>{activeCustomerApp.stepProgress}%</span>
                      </div>
                      <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden border border-slate-700/50">
                        <div 
                          className="bg-sky-500 h-full rounded-full transition-all duration-1000" 
                          style={{ width: `${activeCustomerApp.stepProgress}%` }}
                        ></div>
                      </div>
                    </div>

                    {/* Workflow status timeline check items mapping backend states */}
                    <div className="space-y-4 pt-2">
                      <div className="flex items-center gap-3">
                        <span className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] ${activeCustomerApp.stepProgress >= 20 ? 'bg-sky-500 text-white font-bold' : 'bg-slate-800 text-slate-400'}`}>
                          {activeCustomerApp.stepProgress >= 20 ? <Check size={12} /> : "1"}
                        </span>
                        <div>
                          <p className="text-xs font-bold text-slate-200">Document Transmission</p>
                          <p className="text-[10px] text-slate-400">Secure package transmitted safely</p>
                        </div>
                      </div>

                      <div className="flex items-center gap-3">
                        <span className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] ${activeCustomerApp.stepProgress >= 40 ? 'bg-sky-500 text-white font-bold' : 'bg-slate-800 text-slate-400'}`}>
                          {activeCustomerApp.stepProgress >= 40 ? <Check size={12} /> : "2"}
                        </span>
                        <div>
                          <p className="text-xs font-bold text-slate-200">Data Field Extraction</p>
                          <p className="text-[10px] text-slate-400">Structured JSON character reading</p>
                        </div>
                      </div>

                      <div className="flex items-center gap-3">
                        <span className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] ${activeCustomerApp.stepProgress >= 60 ? 'bg-sky-500 text-white font-bold' : 'bg-slate-800 text-slate-400'}`}>
                          {activeCustomerApp.stepProgress >= 60 ? <Check size={12} /> : "3"}
                        </span>
                        <div>
                          <p className="text-xs font-bold text-slate-200">Consistency Checks</p>
                          <p className="text-[10px] text-slate-400">Compare similarities across source cards</p>
                        </div>
                      </div>

                      <div className="flex items-center gap-3">
                        <span className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] ${activeCustomerApp.stepProgress >= 80 ? 'bg-sky-500 text-white font-bold' : 'bg-slate-800 text-slate-400'}`}>
                          {activeCustomerApp.stepProgress >= 80 ? <Check size={12} /> : "4"}
                        </span>
                        <div>
                          <p className="text-xs font-bold text-slate-200">Missing Elements Audit</p>
                          <p className="text-[10px] text-slate-400">Sign-off validations and blank fields</p>
                        </div>
                      </div>

                      <div className="flex items-center gap-3">
                        <span className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] ${activeCustomerApp.stepProgress >= 90 ? 'bg-sky-500 text-white font-bold' : 'bg-slate-800 text-slate-400'}`}>
                          {activeCustomerApp.stepProgress >= 90 ? <Check size={12} /> : "5"}
                        </span>
                        <div>
                          <p className="text-xs font-bold text-slate-200">Tamper & Forensics Scan</p>
                          <p className="text-[10px] text-slate-400">Check visual overlay manipulations</p>
                        </div>
                      </div>

                      <div className="flex items-center gap-3">
                        <span className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] ${activeCustomerApp.stepProgress >= 100 ? 'bg-emerald-500 text-white font-bold' : 'bg-slate-800 text-slate-400'}`}>
                          {activeCustomerApp.stepProgress >= 100 ? <Check size={12} /> : "6"}
                        </span>
                        <div>
                          <p className="text-xs font-bold text-slate-200">Verification Report Complete</p>
                          <p className="text-[10px] text-slate-400">Final audit recommendation issued</p>
                        </div>
                      </div>
                    </div>

                    {activeCustomerApp.requestedDocuments && activeCustomerApp.requestedDocuments.length > 0 && (
                      <div className="bg-amber-950/80 border border-amber-800/80 p-4 rounded-xl text-xs space-y-1.5 mt-2 shadow-inner">
                        <p className="font-extrabold text-amber-400 flex items-center gap-1.5 uppercase tracking-wide">
                          <AlertTriangle size={14} className="text-amber-500 animate-pulse shrink-0" /> Re-Audit Action Required
                        </p>
                        <p className="text-slate-300 text-[11px] leading-relaxed">
                          The system compliance auditor has returned your file submission and requested corrective document uploads:
                        </p>
                        <div className="bg-slate-950/50 p-2.5 rounded-lg border border-amber-950 mt-1">
                          <ul className="space-y-1 text-amber-300 font-mono text-[10.5px]">
                            {activeCustomerApp.requestedDocuments.map((doc, idx) => (
                              <li key={idx} className="flex items-center gap-1.5">
                                <span className="w-1 h-1 bg-amber-400 rounded-full shrink-0"></span>
                                {doc}
                              </li>
                            ))}
                          </ul>
                        </div>
                        {activeCustomerApp.adminNotes && (
                          <div className="text-[11px] text-slate-400 italic pt-1 border-t border-amber-900/30">
                            Auditor Insight: &ldquo;{activeCustomerApp.adminNotes}&rdquo;
                          </div>
                        )}
                      </div>
                    )}

                    {activeCustomerApp.status === "VERIFIED" && (
                      <div className="bg-emerald-900/60 border border-emerald-700/60 p-4 rounded-xl text-xs space-y-1.5 mt-2">
                        <p className="font-extrabold text-emerald-400 flex items-center gap-1">
                          <CheckCircle2 size={14} /> Congratulations! Profile Verified
                        </p>
                        <p className="text-slate-300">
                          Your KYC is complete. All enterprise financial transactions and high-yield account balances are active.
                        </p>
                      </div>
                    )}
                  </div>

                  {activeCustomerApp.finalKycReport && (
                    <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-sm space-y-4">
                      <div className="flex items-center justify-between">
                        <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider">AI Evaluation Summary</h3>
                        <button
                          onClick={() => handleDownloadReport(activeCustomerApp.id)}
                          className="text-xs font-bold text-indigo-600 hover:text-indigo-800 flex items-center gap-1 bg-indigo-50 px-2 py-1 rounded"
                        >
                          <Download size={13} />
                          Download Report
                        </button>
                      </div>
                      <div className="space-y-3.5 divide-y divide-slate-100">
                        <div className="pt-0">
                          <p className="text-[10px] font-bold text-slate-400 tracking-wider uppercase">Audit Decision Context</p>
                          <p className="text-xs text-slate-700 mt-1">{activeCustomerApp.finalKycReport.verificationSummary}</p>
                        </div>
                        <div className="pt-3.5">
                          <p className="text-[10px] font-bold text-slate-400 tracking-wider uppercase">Risk Evaluation Verdict</p>
                          <p className="text-xs text-slate-700 mt-1">{activeCustomerApp.finalKycReport.fraudAnalysisSummary}</p>
                        </div>
                        <div className="pt-3.5">
                          <p className="text-[10px] font-bold text-slate-400 tracking-wider uppercase">Mandated Recommendation</p>
                          <p className="text-xs text-slate-700 mt-1 font-semibold text-slate-800">{activeCustomerApp.finalKycReport.finalRecommendation}</p>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            )}
          </div>
        )}

        {/* ========================================== */}
        {/* AUTHORITY / ADMIN PORTAL VIEW              */}
        {/* ========================================== */}
        {currentPortal === "authority" && (
          <div className="flex-1 flex flex-col lg:flex-row h-full overflow-hidden w-full">
            
            {/* Sidebar with Stats, Status, Filters */}
            <aside className="w-full lg:w-72 bg-white border-b lg:border-b-0 lg:border-r border-slate-200 p-6 flex flex-col gap-6 shrink-0 overflow-y-auto">
              <div className="space-y-1">
                <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-3">Auditor Search & Controls</p>
                
                {/* Search Inbox */}
                <div className="relative">
                  <Search className="absolute left-3 top-2.5 h-4 w-4 text-slate-400" />
                  <input
                    type="text"
                    placeholder="Search apps by key fields..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-9 pr-4 py-2 w-full bg-slate-50 border border-slate-200 rounded-lg text-xs font-semibold placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-sky-500/20 focus:border-sky-500"
                  />
                </div>
              </div>

              {/* Status Selector Filter */}
              <div className="space-y-2">
                <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Onboard Status Filter</label>
                <select
                  value={statusFilter}
                  onChange={(e) => setStatusFilter(e.target.value)}
                  className="w-full p-2 bg-slate-50 border border-slate-200 rounded-lg text-xs font-semibold text-slate-700 focus:outline-none"
                >
                  <option value="ALL">Show All Statuses</option>
                  <option value="VERIFIED">Verified</option>
                  <option value="PARTIALLY VERIFIED">Partially Verified</option>
                  <option value="REJECTED">Rejected</option>
                  <option value="MANUAL REVIEW REQUIRED">Manual Audit</option>
                  <option value="PROCESSING">AI Running</option>
                  <option value="PENDING_UPLOAD">Draft Pending</option>
                </select>
              </div>

              {/* Risk Level Filter selection */}
              <div className="space-y-2">
                <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Risk Category</label>
                <div className="grid grid-cols-2 gap-2">
                  {["ALL", "LOW", "MEDIUM", "HIGH"].map((level) => (
                    <button
                      key={level}
                      onClick={() => setRiskFilter(level)}
                      className={`px-3 py-1.5 rounded-lg border text-left text-[11px] font-bold transition-all ${
                        riskFilter === level
                          ? "bg-slate-900 text-white border-slate-900 shadow-sm"
                          : "bg-slate-50 text-slate-600 border-slate-200 hover:bg-slate-100"
                      }`}
                    >
                      {level}
                    </button>
                  ))}
                </div>
              </div>

              <hr className="border-slate-100" />

              {/* Simple Re-trigger list details summary */}
              <div className="space-y-3">
                <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Onboard Status Metric</p>
                <div className="space-y-2">
                  <div className="flex justify-between items-center text-xs text-slate-600">
                    <span>Total Submissions</span>
                    <span className="font-extrabold text-slate-800">{applications.length}</span>
                  </div>
                  <div className="flex justify-between items-center text-xs text-slate-600">
                    <span>Verified Success</span>
                    <span className="font-extrabold text-slate-800">
                      {applications.filter(a => a.status === "VERIFIED").length}
                    </span>
                  </div>
                  <div className="flex justify-between items-center text-xs text-slate-600">
                    <span>Manual Auditor Handlers</span>
                    <span className="font-extrabold text-amber-600">
                      {applications.filter(a => a.status === "MANUAL REVIEW REQUIRED").length}
                    </span>
                  </div>
                  <div className="flex justify-between items-center text-xs text-slate-600">
                    <span>High Risk Rejections</span>
                    <span className="font-extrabold text-red-600">
                      {applications.filter(a => a.status === "REJECTED").length}
                    </span>
                  </div>
                </div>
              </div>

              {/* Service status widget */}
              <div className="mt-auto p-4 bg-[#0F172A] rounded-xl text-white">
                <p className="text-[9px] uppercase font-bold text-slate-400 mb-2 tracking-wider">Audit Security Protocol</p>
                <div className="flex justify-between text-[11px] mb-1">
                  <span className="text-slate-300">Gemini Flash AI Stream</span>
                  <span className="text-emerald-400 font-bold">Active</span>
                </div>
                <div className="w-full bg-slate-800 h-1 rounded-full overflow-hidden mt-2">
                  <div className="w-full bg-sky-500 h-full"></div>
                </div>
              </div>
            </aside>

            {/* Central Panel Layout for application listings & auditing reviews */}
            <main className="flex-1 flex flex-col md:flex-row overflow-hidden max-w-full">
              
              {/* Left Column: Applications Grid */}
              <div className="w-full md:w-1/2 flex flex-col border-b md:border-b-0 md:border-r border-slate-200 overflow-y-auto">
                <div className="p-4 bg-slate-50 border-b border-slate-200 flex justify-between items-center shrink-0">
                  <span className="text-xs font-bold text-slate-500 uppercase tracking-widest">
                    Records Found ({filteredApps.length})
                  </span>
                  <button 
                    onClick={fetchApplications}
                    className="p-1 text-slate-500 hover:text-indigo-600 transition"
                    title="Force refresh database from memory sandbox"
                  >
                    <RefreshCw size={14} />
                  </button>
                </div>

                <div className="divide-y divide-slate-100 flex-1">
                  {filteredApps.length === 0 ? (
                    <div className="p-8 text-center text-slate-400 text-xs">
                      No customer applications correspond to current matching search constraints.
                    </div>
                  ) : (
                    filteredApps.map((app) => (
                      <div
                        key={app.id}
                        onClick={() => setSelectedAppId(app.id)}
                        className={`p-4 hover:bg-slate-50 cursor-pointer transition-all duration-250 flex flex-col gap-2.5 ${
                          selectedAppId === app.id
                            ? "bg-slate-50 border-l-4 border-sky-500"
                            : "bg-white"
                        }`}
                      >
                        <div className="flex justify-between items-start gap-2">
                          <div className="space-y-0.5">
                            <h4 className="font-bold text-sm text-[#0F172A] tracking-tight">{app.customerName}</h4>
                            <p className="text-[11px] text-slate-400 font-medium">{app.customerEmail}</p>
                          </div>
                          {renderStatusBadge(app.status)}
                        </div>

                        <div className="flex items-center justify-between text-[11px] text-slate-500 pt-1 border-t border-slate-50">
                          <span className="font-mono bg-slate-100 text-slate-700 px-1 py-0.5 rounded text-[10px]">{app.id}</span>
                          <span className="flex items-center gap-1">
                            Risk Level: {renderRiskBadge(app.fraudDetection?.riskLevel)}
                          </span>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </div>

              {/* Right Column: Active Auditing Detail Panel */}
              <div className="w-full md:w-1/2 flex flex-col overflow-y-auto bg-[#F8FAFC]">
                {selectedApp ? (
                  <div className="p-6 space-y-6">
                    {/* Security detail validation view */}
                    <div className="flex flex-col xl:flex-row xl:items-center justify-between gap-4 border-b border-slate-200 pb-5">
                      <div className="space-y-1">
                        <h2 className="text-xl font-bold text-slate-900 tracking-tight uppercase">Audit & Verified Details</h2>
                        <p className="text-xs text-slate-400 leading-tight">
                          Review extracted metadata outputs context and forensic image scans below
                        </p>
                      </div>

                      <div className="flex gap-2">
                        <button
                          onClick={() => handleDownloadReport(selectedApp.id)}
                          className="px-3.5 py-1.5 border border-slate-300 hover:bg-slate-100 rounded-lg text-xs font-bold text-slate-700 transition flex items-center gap-1"
                        >
                          <Download size={13} />
                          Report Draft
                        </button>
                      </div>
                    </div>

                    {/* Operational system feedback popups */}
                    {feedbackMessage && (
                      <div className={`p-4 border rounded-xl text-xs font-semibold ${feedbackMessage.type === 'success' ? 'bg-emerald-50 border-emerald-200 text-emerald-800' : 'bg-rose-50 border-rose-200 text-rose-800'}`}>
                        {feedbackMessage.text}
                      </div>
                    )}

                    {/* SECTION 1: EXTRACTED JSON STRUCTURE (Sleek Interface highlight) */}
                    <div className="bg-white rounded-2xl shadow-sm border border-slate-200 p-5 space-y-3">
                      <div className="flex items-center justify-between mb-1">
                        <h3 className="text-[10px] font-black text-slate-400 uppercase tracking-widest flex items-center gap-1.5">
                          <span className="w-1.5 h-1.5 bg-sky-500 rounded-full"></span> 
                          AI Extracted Legal JSON Dataset
                        </h3>
                        {selectedApp.customerData && (
                          <span className="text-[9px] bg-indigo-50 border border-indigo-100 text-indigo-700 font-mono px-1.5 py-0.5 rounded font-black">
                            PASSED PARSING
                          </span>
                        )}
                      </div>

                      {selectedApp.customerData ? (
                        <div className="bg-slate-900 rounded-xl p-4 font-mono text-[11px] leading-relaxed text-sky-300 max-h-56 overflow-y-auto shadow-inner border border-slate-800">
                          <span className="text-slate-500">{"{"}</span>
                          <div className="pl-4">
                            <span className="text-slate-500">"customer_identity":</span> <span className="text-slate-400">{"{"}</span>
                            <div className="pl-4">
                              <span className="text-indigo-400">"full_name":</span> <span className="text-emerald-400">"{selectedApp.customerData.name}"</span>,<br />
                              <span className="text-indigo-400">"dob":</span> <span className="text-emerald-400">"{selectedApp.customerData.dob}"</span>,<br />
                              <span className="text-indigo-400">"pan_number":</span> <span className="text-emerald-400">"{selectedApp.customerData.panNumber || 'UNMATCHED_DRAFT'}"</span>,<br />
                              <span className="text-indigo-400">"aadhaar_id":</span> <span className="text-emerald-400">"{selectedApp.customerData.aadhaarNumber || 'UNMATCHED_DRAFT'}"</span>
                            </div>
                            <span className="text-slate-400">{"},"}</span><br />

                            <span className="text-slate-500">"address_meta":</span> <span className="text-slate-400">{"{"}</span>
                            <div className="pl-4">
                              <span className="text-indigo-400">"full_address":</span> <span className="text-emerald-400">"{selectedApp.customerData.address}"</span>
                            </div>
                            <span className="text-slate-400">{"},"}</span><br />

                            <span className="text-slate-500">"contact":</span> <span className="text-slate-400">{"{"}</span>
                            <div className="pl-4">
                              <span className="text-indigo-400">"email":</span> <span className="text-emerald-400">"{selectedApp.customerData.email}"</span>,<br />
                              <span className="text-indigo-400">"phone":</span> <span className="text-emerald-400">"{selectedApp.customerData.mobileNumber}"</span>
                            </div>
                            <span className="text-slate-400">{"}"}</span>
                          </div>
                          <span className="text-slate-500">{"}"}</span>
                        </div>
                      ) : (
                        <div className="p-4 text-center bg-slate-50 text-slate-400 rounded-lg text-xs font-semibold">
                          No text extraction available. Customer has not uploaded identity files yet.
                        </div>
                      )}
                    </div>

                    {/* SECTION 2: IDENTITY CONSISTENCY AND MATCH SCORES */}
                    <div className="bg-white rounded-2xl shadow-sm border border-slate-200 p-5 space-y-4">
                      <h3 className="text-[10px] font-bold text-slate-400 uppercase tracking-widest flex items-center gap-1.5 border-b border-slate-100 pb-2">
                        <span className="w-1.5 h-1.5 bg-blue-500 rounded-full"></span>
                        Card Consistency Math Analysis
                      </h3>

                      {selectedApp.consistencyCheck ? (
                        <div className="space-y-4">
                          <div className="grid grid-cols-3 gap-3">
                            <div className="p-3 bg-slate-50 rounded-lg text-center border border-slate-100">
                              <p className="text-[10px] uppercase font-bold text-slate-400">Name Match</p>
                              <p className={`text-xl font-black mt-1 ${selectedApp.consistencyCheck.nameMatchScore >= 90 ? 'text-emerald-600' : 'text-amber-600'}`}>
                                {selectedApp.consistencyCheck.nameMatchScore}%
                              </p>
                            </div>
                            <div className="p-3 bg-slate-50 rounded-lg text-center border border-slate-100">
                              <p className="text-[10px] uppercase font-bold text-slate-400">DOB Match</p>
                              <p className={`text-xl font-black mt-1 ${selectedApp.consistencyCheck.dobMatchScore >= 90 ? 'text-emerald-600' : 'text-amber-500'}`}>
                                {selectedApp.consistencyCheck.dobMatchScore}%
                              </p>
                            </div>
                            <div className="p-3 bg-slate-50 rounded-lg text-center border border-slate-100">
                              <p className="text-[10px] uppercase font-bold text-slate-400">Address Match</p>
                              <p className={`text-xl font-black mt-1 ${selectedApp.consistencyCheck.addressMatchScore >= 80 ? 'text-emerald-600' : 'text-amber-500'}`}>
                                {selectedApp.consistencyCheck.addressMatchScore}%
                              </p>
                            </div>
                          </div>

                          <div className="space-y-2 text-xs">
                            <div className="flex justify-between font-bold text-slate-700">
                              <span>PAN Format Struct validation</span>
                              <span>{selectedApp.consistencyCheck.panFormatOk ? "VALID TAXPASS" : "INVALID TAXPAD"}</span>
                            </div>
                            <div className="flex justify-between font-bold text-slate-700">
                              <span>Aadhaar Mathematical Checksum</span>
                              <span className={selectedApp.consistencyCheck.aadhaarFormatOk ? "text-emerald-600 font-extrabold" : "text-rose-600 font-extrabold"}>
                                {selectedApp.consistencyCheck.aadhaarFormatOk ? "VALID CHECKSUM" : "CHECKSUM FAILED ALERT"}
                              </span>
                            </div>
                          </div>

                          <p className="text-xs text-slate-500 italic leading-relaxed pt-2 border-t border-slate-100">
                            <strong>AI Observe Layer:</strong> {selectedApp.consistencyCheck.observations}
                          </p>
                        </div>
                      ) : (
                        <div className="p-4 text-center bg-slate-50 text-slate-400 rounded-lg text-xs font-semibold">
                          Perform AI analysis to generate consistency match scores.
                        </div>
                      )}
                    </div>

                    {/* SECTION 3: IMAGE CLARITY CHECK GAPS */}
                    <div className="bg-white rounded-2xl shadow-sm border border-slate-200 p-5 space-y-4">
                      <h3 className="text-[10px] font-bold text-slate-400 uppercase tracking-widest flex items-center gap-1.5 border-b border-slate-100 pb-2">
                        <span className="w-1.5 h-1.5 bg-amber-500 rounded-full"></span>
                        Completeness & Blur Matrix Checks
                      </h3>

                      {selectedApp.missingFieldsCheck ? (
                        <div className="space-y-3.5">
                          <div className="grid grid-cols-2 gap-4 text-xs font-bold text-slate-700">
                            <div className="flex justify-between">
                              <span>Form Blank Sign-offline</span>
                              <span className={selectedApp.missingFieldsCheck.missingSignatures ? "text-rose-600 font-black" : "text-emerald-600 font-black"}>
                                {selectedApp.missingFieldsCheck.missingSignatures ? "BLANK / MISSING" : "VERIFIED COMPLETED"}
                              </span>
                            </div>
                            <div className="flex justify-between">
                              <span>Image Resolution Resolution</span>
                              <span className={selectedApp.missingFieldsCheck.lowQualityImages ? "text-rose-600 font-black uppercase" : "text-emerald-600 font-black"}>
                                {selectedApp.missingFieldsCheck.lowQualityImages ? "Blur / Poor Quality" : "HIGH CLARITY LEVEL"}
                              </span>
                            </div>
                          </div>

                          {selectedApp.missingFieldsCheck.blankFields.length > 0 && (
                            <div className="p-3 bg-red-50 text-red-800 rounded-lg text-xs border border-red-100 space-y-1">
                              <p className="font-extrabold">Identified Empty Mandatory Blanks:</p>
                              <div className="flex flex-wrap gap-1.5 pt-1">
                                {selectedApp.missingFieldsCheck.blankFields.map((field, i) => (
                                  <span key={i} className="text-[10px] bg-red-100/80 px-2 py-0.5 rounded font-black uppercase">{field}</span>
                                ))}
                              </div>
                            </div>
                          )}

                          <p className="text-xs text-slate-500 leading-relaxed border-t border-slate-100 pt-2">
                            <strong>AI Integrity Note:</strong> {selectedApp.missingFieldsCheck.observations}
                          </p>
                        </div>
                      ) : (
                        <div className="p-4 text-center bg-slate-50 text-slate-400 rounded-lg text-xs font-semibold">
                          Analysis pending. Document completeness validation required.
                        </div>
                      )}
                    </div>

                    {/* SECTION 4: SECURITY TAMPER DETECTION MATRIX */}
                    <div className="bg-white rounded-2xl shadow-sm border border-slate-200 p-5 space-y-4">
                      <div className="flex justify-between items-center pb-2 border-b border-indigo-100/50">
                        <h3 className="text-[10px] font-bold text-slate-400 uppercase tracking-widest flex items-center gap-1.5">
                          <span className="w-1.5 h-1.5 bg-rose-600 rounded-full"></span>
                          Crypto Security & Tamper Detection Check
                        </h3>
                        {selectedApp.fraudDetection && (
                          <span className="font-extrabold text-[10px] px-2 py-0.5 rounded bg-slate-900 text-white font-mono">
                            VERDICT: {selectedApp.fraudDetection.riskLevel}
                          </span>
                        )}
                      </div>

                      {selectedApp.fraudDetection ? (
                        <div className="space-y-3.5">
                          {/* Risk Level gauge */}
                          <div>
                            <div className="flex justify-between text-xs font-bold text-slate-600 mb-1">
                              <span>Security Aggregated Score</span>
                              <span>{selectedApp.fraudDetection.riskScore} / 100</span>
                            </div>
                            <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden">
                              <div 
                                className={`h-full rounded-full transition-all duration-500 ${
                                  selectedApp.fraudDetection.riskLevel === 'HIGH' ? 'bg-rose-600' :
                                  selectedApp.fraudDetection.riskLevel === 'MEDIUM' ? 'bg-amber-500' : 'bg-emerald-600'
                                }`}
                                style={{ width: `${selectedApp.fraudDetection.riskScore}%` }}
                              ></div>
                            </div>
                          </div>

                          {/* Specific Fraud Indicators */}
                          <div className="grid grid-cols-2 gap-3.5 text-xs font-bold pt-1.5">
                            <div className="flex justify-between p-2 bg-slate-50 rounded">
                              <span className="text-slate-500 text-[10.5px]">Tampered PAN Info</span>
                              <span className={selectedApp.fraudDetection.fakePanDetected ? "text-rose-600" : "text-emerald-600"}>
                                {selectedApp.fraudDetection.fakePanDetected ? "ALERT TRIGGER" : "CLEAR"}
                              </span>
                            </div>
                            <div className="flex justify-between p-2 bg-slate-50 rounded">
                              <span className="text-slate-500 text-[10.5px]">Cloned Aadhaar</span>
                              <span className={selectedApp.fraudDetection.fakeAadhaarDetected ? "text-rose-600" : "text-emerald-600"}>
                                {selectedApp.fraudDetection.fakeAadhaarDetected ? "ALERT TRIGGER" : "CLEAR"}
                              </span>
                            </div>
                            <div className="flex justify-between p-2 bg-slate-50 rounded">
                              <span className="text-slate-500 text-[10.5px]">Document Photo Overlays</span>
                              <span className={selectedApp.fraudDetection.editedDocuments ? "text-rose-600" : "text-emerald-600"}>
                                {selectedApp.fraudDetection.editedDocuments ? "MODIFICATION SPOTTED" : "CLEAR"}
                              </span>
                            </div>
                            <div className="flex justify-between p-2 bg-slate-50 rounded">
                              <span className="text-slate-500 text-[10.5px]">Identity Re-occurrence</span>
                              <span className={selectedApp.fraudDetection.duplicateIdentity ? "text-rose-600" : "text-emerald-600"}>
                                {selectedApp.fraudDetection.duplicateIdentity ? "DUPLICATE MATCH" : "UNIQUE"}
                              </span>
                            </div>
                          </div>

                          {/* Specific Auditor indicators list */}
                          <div className="space-y-1.5 pt-2 border-t border-slate-100">
                            <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Auditor Reason Statement Logs</p>
                            <ul className="space-y-1.5">
                              {selectedApp.fraudDetection.reasons.map((reason, index) => (
                                <li key={index} className="text-xs text-slate-700 flex items-start gap-1.5 leading-tight">
                                  <span className="text-slate-400 mt-0.5 shrink-0">&middot;</span>
                                  {reason}
                                </li>
                              ))}
                            </ul>
                          </div>
                        </div>
                      ) : (
                        <div className="p-4 text-center bg-slate-50 text-slate-400 rounded-lg text-xs font-semibold">
                          Tamper analysis scan pending. Please trigger calculations by processing the files.
                        </div>
                      )}
                    </div>

                    {/* SECTION 5: SIGNATURES AND IMAGE REPRESENTATIONS */}
                    <div className="p-5 bg-white border border-slate-200 rounded-2xl shadow-sm space-y-4">
                      <h3 className="text-[10px] font-bold text-slate-400 uppercase tracking-widest flex items-center gap-1.5">
                        <span className="w-1.5 h-1.5 bg-indigo-500 rounded-full"></span>
                        Compliance Document Previews
                      </h3>

                      <div className="grid grid-cols-3 gap-3">
                        <div className="border border-slate-200 rounded-xl bg-slate-50 flex flex-col items-center justify-center p-3 text-center h-32 relative group overflow-hidden">
                          {selectedApp.aadhaarImage ? (
                            <img src={selectedApp.aadhaarImage} alt="Aadhaar" className="absolute inset-0 w-full h-full object-cover group-hover:scale-105 transition duration-300" />
                          ) : (
                            <div className="text-[10px] text-slate-400 font-extrabold uppercase">NO FILE</div>
                          )}
                          <div className="absolute bottom-0 inset-x-0 bg-slate-900/80 text-white text-[9px] py-1 font-bold">
                            {selectedApp.aadhaarImageName || "Aadhaar Card"}
                          </div>
                        </div>

                        <div className="border border-slate-200 rounded-xl bg-slate-50 flex flex-col items-center justify-center p-3 text-center h-32 relative group overflow-hidden">
                          {selectedApp.panImage ? (
                            <img src={selectedApp.panImage} alt="PAN" className="absolute inset-0 w-full h-full object-cover group-hover:scale-105 transition duration-300" />
                          ) : (
                            <div className="text-[10px] text-slate-400 font-extrabold uppercase">NO FILE</div>
                          )}
                          <div className="absolute bottom-0 inset-x-0 bg-slate-900/80 text-white text-[9px] py-1 font-bold">
                            {selectedApp.panImageName || "PAN Card"}
                          </div>
                        </div>

                        <div className="border border-slate-200 rounded-xl bg-slate-50 flex flex-col items-center justify-center p-3 text-center h-32 relative group overflow-hidden">
                          {selectedApp.formImage ? (
                            <img src={selectedApp.formImage} alt="Form" className="absolute inset-0 w-full h-full object-cover group-hover:scale-105 transition duration-300" />
                          ) : (
                            <div className="text-[10px] text-slate-400 font-extrabold uppercase">NO FILE</div>
                          )}
                          <div className="absolute bottom-0 inset-x-0 bg-slate-900/80 text-white text-[9px] py-1 font-bold">
                            {selectedApp.formImageName || "Account Form"}
                          </div>
                        </div>
                      </div>
                    </div>

                    {/* SECTION 6: MANDATED ACTION & COMPLIANCE SIGN OFF DIALOG PANEL */}
                    <div className="bg-slate-900 text-white rounded-2xl border border-slate-800 p-6 space-y-5 shadow-xl">
                      <h3 className="font-extrabold text-sm uppercase tracking-wider text-sky-400 flex items-center gap-1.5">
                        <Shield size={16} /> Lead Auditor Verification Actions
                      </h3>

                      <div className="space-y-4">
                        <div className="space-y-1.5">
                          <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block">Audit Compliance Notes</label>
                          <textarea
                            placeholder="Add specific details or issues regarding the audit matching process..."
                            value={adminNotes}
                            onChange={(e) => setAdminNotes(e.target.value)}
                            rows={3}
                            className="w-full bg-slate-800 border border-slate-700 rounded-xl px-4 py-2.5 text-xs text-white placeholder:text-slate-500 focus:outline-none focus:ring-2 focus:ring-sky-500/20 focus:border-sky-500 transition"
                          />
                        </div>

                        {/* Request more documents workspace */}
                        <div className="space-y-2 border-t border-slate-800 pt-3.5">
                          <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block">Request Re-upload of Document</label>
                          <div className="flex flex-wrap gap-2">
                            {["Aadhaar Card Copy", "PAN Card Copy", "Signature Enrollment Block", "Signed Customer Form"].map((doc) => {
                              const isSelected = docRequestList.includes(doc);
                              return (
                                <button
                                  key={doc}
                                  type="button"
                                  onClick={() => toggleDocRequestItem(doc)}
                                  className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition ${
                                    isSelected 
                                      ? "bg-amber-500 text-slate-950 font-bold" 
                                      : "bg-slate-800 hover:bg-slate-700 border border-slate-700/60 text-slate-300"
                                  }`}
                                >
                                  {doc}
                                </button>
                              );
                            })}
                          </div>

                          <div className="flex gap-2 mt-4">
                            <input
                              type="text"
                              value={customDocRequest}
                              onChange={(e) => setCustomDocRequest(e.target.value)}
                              placeholder="Specify alternative file request details..."
                              className="bg-slate-800 text-xs text-white border border-slate-700 rounded-lg px-3 py-1.5 flex-1 focus:outline-none placeholder:text-slate-500"
                            />
                            <button
                              type="button"
                              onClick={addCustomDocRequest}
                              className="px-3 py-1.5 text-xs font-bold bg-slate-800 border border-slate-700 hover:bg-slate-700 rounded-lg text-slate-200"
                            >
                              Add File
                            </button>
                          </div>

                          {docRequestList.length > 0 && (
                            <button
                              type="button"
                              onClick={handleRequestMoreDocs}
                              className="mt-2 w-full text-xs font-black uppercase tracking-wider bg-amber-500 hover:bg-amber-600 text-slate-950 py-2.5 rounded-xl transition"
                            >
                              Request selected files ({docRequestList.length})
                            </button>
                          )}
                        </div>

                        {/* Decision Switch buttons */}
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-2.5 pt-3.5 border-t border-slate-800">
                          <button
                            onClick={() => handleAdminAction("REJECTED")}
                            className="bg-rose-600 hover:bg-rose-700 text-white font-bold py-2.5 px-4 rounded-xl text-xs uppercase tracking-wider shadow"
                          >
                            Reject Application
                          </button>
                          <button
                            onClick={() => handleAdminAction("MANUAL REVIEW REQUIRED")}
                            className="bg-slate-800 hover:bg-slate-700 border border-slate-700/60 text-slate-200 font-bold py-2.5 px-4 rounded-xl text-xs uppercase tracking-wider"
                          >
                            Flag for Re-Audit
                          </button>
                          <button
                            onClick={() => handleAdminAction("VERIFIED")}
                            className="bg-sky-600 hover:bg-sky-700 text-white font-bold py-2.5 px-4 rounded-xl text-xs uppercase tracking-wider shadow"
                          >
                            Approve Verify
                          </button>
                        </div>
                      </div>
                    </div>

                    {/* SECTION 7: AUDIT LOGS HISTORY */}
                    <div className="bg-white rounded-2xl border border-slate-200 p-5 space-y-4">
                      <h3 className="text-[10px] font-bold text-slate-400 uppercase tracking-widest border-b border-slate-100 pb-2">
                        Compliance Officer Audit Chronology
                      </h3>
                      <div className="space-y-4 max-h-48 overflow-y-auto pr-2">
                        {selectedApp.auditLogs.map((log, index) => (
                          <div key={index} className="text-xs space-y-0.5">
                            <div className="flex justify-between font-semibold text-slate-800">
                              <span>{log.message}</span>
                              <span className="text-[9.5px] text-slate-400 font-normal">
                                {new Date(log.timestamp).toLocaleDateString()} {new Date(log.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                              </span>
                            </div>
                            <p className="text-[10.5px] text-slate-400">Actor Context: {log.actor}</p>
                          </div>
                        ))}
                      </div>
                    </div>

                  </div>
                ) : (
                  <div className="p-8 text-center text-slate-400 text-xs flex flex-col justify-center h-full">
                    Select a customer application from the list to begin compliance evaluation auditing actions.
                  </div>
                )}
              </div>
            </main>
          </div>
        )}

      </div>

      {/* Enterprise Compliant Footer */}
      <footer className="h-10 bg-white border-t border-slate-200 flex items-center justify-between px-8 text-[10px] text-slate-400 shrink-0 relative z-30">
        <div className="flex gap-4">
          <span>Pipeline State: <span className="text-slate-600 font-semibold uppercase">ONLINE</span></span>
          <span>Response latency: <span className="text-slate-600 font-semibold">14ms</span></span>
          <span>Nodes: <span className="text-slate-600 font-semibold">8/8 SECURED</span></span>
        </div>
        <div>
          &copy; {new Date().getFullYear()} RESERVE VAULT CO. - STRICTLY PRIVACY COMPLIANT SYSTEM
        </div>
      </footer>
    </div>
  );
}
